
import React, { useState, useRef, useEffect } from 'react';
import { evolveSprite } from '../services/geminiService';
import { supabase, saveNode, uploadSprite, fetchAllNodes } from '../services/supabaseService';
import { SpriteEvolution, EvolutionNode, GearSlots, RarityTier, OutfitVariation } from '../types';

const RARITIES: RarityTier[] = ['Common', 'Rare', 'Epic', 'Legendary'];
const VARIATIONS: OutfitVariation[] = ['Standard', 'Ornate', 'Battle-worn', 'Simple'];

type TabType = 'ARMORY' | 'ARCHETYPES' | 'FORGE_SPEC' | 'TERMINAL';
type CollectionType = 'STANDARD' | 'EXOTIC_STEEL';

interface Archetype {
  id: string;
  name: string;
  class: string;
  race: string;
  category: CollectionType;
  gear: GearSlots;
  vibe: string;
}

const ARCHETYPE_LIBRARY: Archetype[] = [
  // STANDARD COLLECTION
  {
    id: 'elf_ranger',
    name: 'Sun-Elf Stalker',
    class: 'Ranger',
    race: 'Elf',
    category: 'STANDARD',
    vibe: 'Practical',
    gear: { head: 'Leather Hood', body: 'Scale mail', legs: 'Soft boots', weapon: 'Yew Longbow', back: 'Quiver' }
  },
  {
    id: 'dwarf_cleric',
    name: 'Iron-Hill Priest',
    class: 'Cleric',
    race: 'Dwarf',
    category: 'STANDARD',
    vibe: 'Tanky',
    gear: { head: 'Silver Tiara', body: 'Plate mail', legs: 'Metal greaves', weapon: 'Runic hammer', back: 'Tower shield' }
  },
  {
    id: 'halfling_rogue',
    name: 'Silent Shadow',
    class: 'Rogue',
    race: 'Halfling',
    category: 'STANDARD',
    vibe: 'Stealth',
    gear: { head: 'Face mask', body: 'Leather vest', legs: 'Cloth wraps', weapon: 'Obsidian daggers', back: 'Pick toolkit' }
  },
  // EXOTIC STEEL COLLECTION (Queen's Blade Inspired)
  {
    id: 'leina_knight',
    name: 'Exiled Princess',
    class: 'Knight',
    race: 'Human',
    category: 'EXOTIC_STEEL',
    vibe: 'Heroic / Revealing',
    gear: { head: 'Dragon Tiara', body: 'Silver plate bikini-armor with blue trim', legs: 'Thigh-high silver greaves', weapon: 'Longsword', back: 'Crimson cape' }
  },
  {
    id: 'nowa_guardian',
    name: 'Forest Sentinel',
    class: 'Guardian',
    race: 'Beast-kin',
    category: 'EXOTIC_STEEL',
    vibe: 'Nature / Minimalist',
    gear: { head: 'Floral circlet', body: 'Green leaf-patterned bodice', legs: 'Bare legs with floral vines', weapon: 'Holy Staff', back: 'Spirit monkey' }
  },
  {
    id: 'tomoe_miko',
    name: 'Warrior Priestess',
    class: 'Miko',
    race: 'Human',
    category: 'EXOTIC_STEEL',
    vibe: 'Traditional / Battle-worn',
    gear: { head: 'Red ribbon', body: 'Shredded Miko kimono (open chest design)', legs: 'Traditional tabi with sandals', weapon: 'Katana', back: 'Paper charms' }
  },
  {
    id: 'echidna_merc',
    name: 'Desert Viper',
    class: 'Mercenary',
    race: 'Elf',
    category: 'EXOTIC_STEEL',
    vibe: 'Lethal / Exotic',
    gear: { head: 'Snake headband', body: 'Brown scaled leather wrap', legs: 'Bare feet with golden anklets', weapon: 'Serpent Scimitar', back: 'Cobra shield' }
  },
  {
    id: 'airi_maid',
    name: 'Ghost Maid',
    class: 'Assassin',
    race: 'Undead',
    category: 'EXOTIC_STEEL',
    vibe: 'Gothic / Fragile',
    gear: { head: 'Maid frill cap', body: 'Tattered Victorian maid outfit', legs: 'Black stockings with garters', weapon: 'Scythe', back: 'Spirit lanterns' }
  },
  {
    id: 'cattleya_slayer',
    name: 'Giant Slayer',
    class: 'Blacksmith',
    race: 'Human',
    category: 'EXOTIC_STEEL',
    vibe: 'Heavy / Curvy',
    gear: { head: 'Silver glasses', body: 'Heavy plate bodice (high neckline)', legs: 'Leather apron over boots', weapon: 'Colossal Greatsword', back: 'Anvil pack' }
  }
];

const compareSilhouettes = async (img1: string, img2: string): Promise<number> => {
  const getMask = (src: string): Promise<Uint8ClampedArray> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 64; canvas.height = 64;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(new Uint8ClampedArray());
        ctx.drawImage(img, 0, 0, 64, 64);
        const data = ctx.getImageData(0, 0, 64, 64).data;
        const mask = new Uint8ClampedArray(64 * 64);
        for (let i = 0; i < data.length; i += 4) mask[i / 4] = data[i + 3] > 10 ? 1 : 0;
        resolve(mask);
      };
      img.src = src;
    });
  };
  const [mask1, mask2] = await Promise.all([getMask(img1), getMask(img2)]);
  if (mask1.length === 0 || mask2.length === 0) return 0;
  let matches = 0;
  for (let i = 0; i < mask1.length; i++) if (mask1[i] === mask2[i]) matches++;
  return (matches / mask1.length) * 100;
};

interface TreeBranchProps {
  node: EvolutionNode;
  allNodes: EvolutionNode[];
  onSelect: (node: EvolutionNode) => void;
  activeId: string | null;
}

const TreeBranch: React.FC<TreeBranchProps> = ({ node, allNodes, onSelect, activeId }) => {
  const children = allNodes.filter(n => n.parentId === node.id);
  const isActive = activeId === node.id;
  return (
    <div className="flex items-start">
      <div className="flex flex-col items-center relative">
        <button
          onClick={() => onSelect(node)}
          className={`group flex flex-col items-center p-3 rounded-xl border-2 transition-all duration-300 relative z-10 
            ${isActive ? 'bg-indigo-900/30 border-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.3)]' : 'bg-[#14171c] border-slate-800 hover:border-slate-600 hover:-translate-y-1'}`}
        >
          <div className="w-20 h-20 mb-2 relative flex items-center justify-center overflow-hidden">
            <img crossOrigin="anonymous" src={node.image} className="w-full h-full object-contain image-rendering-pixelated drop-shadow-lg" style={{ imageRendering: 'pixelated' }} />
          </div>
          <div className="flex flex-col items-center gap-1">
            <span className={`text-[7px] font-bold uppercase tracking-widest ${isActive ? 'text-indigo-400' : 'text-slate-500'}`}>{node.id.startsWith('root') ? 'ROOT' : `GEN_${node.id.slice(-4).toUpperCase()}`}</span>
          </div>
        </button>
        {children.length > 0 && <div className="absolute top-1/2 left-full w-8 h-[2px] bg-slate-800 z-0"></div>}
      </div>
      {children.length > 0 && (
        <div className="ml-8 flex flex-col gap-6 relative border-l-2 border-slate-800 pl-8 py-2">
          {children.map(child => <TreeBranch key={child.id} node={child} allNodes={allNodes} onSelect={onSelect} activeId={activeId} />)}
        </div>
      )}
    </div>
  );
};

export const SpriteForge: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('ARMORY');
  const [selectedCollection, setSelectedCollection] = useState<CollectionType>('STANDARD');
  const [activeNodeId, setActiveNodeId] = useState<string | null>(null);
  const [sliderPos, setSliderPos] = useState(50);
  const [evolution, setEvolution] = useState<SpriteEvolution>({ id: 'initial', originalImage: '', evolvedImage: null, outfitDescription: '', timestamp: Date.now(), status: 'idle' });
  const [gear, setGear] = useState<GearSlots>({ head: '', body: '', legs: '', weapon: '', back: '' });
  const [rarity, setRarity] = useState<RarityTier>('Common');
  const [variation, setVariation] = useState<OutfitVariation>('Standard');
  const [history, setHistory] = useState<EvolutionNode[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [driftScore, setDriftScore] = useState<number>(100);
  const [engineTier, setEngineTier] = useState<'FLASH' | 'PRO'>('FLASH');
  const [hasUserKey, setHasUserKey] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [justInjected, setJustInjected] = useState<boolean>(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const terminalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const initEngine = async () => {
      // @ts-ignore
      const hasKey = await window.aistudio?.hasSelectedApiKey?.();
      setHasUserKey(!!hasKey);
      
      if (supabase) {
        setIsSyncing(true);
        addLog("SUPABASE: ATTEMPTING HANDSHAKE...");
        try {
          const nodes = await fetchAllNodes();
          if (nodes.length > 0) {
            setHistory(nodes);
            const lastNode = nodes[nodes.length - 1];
            setActiveNodeId(lastNode.id);
            setEvolution(prev => ({ ...prev, originalImage: lastNode.image }));
            addLog(`SUPABASE: SYNC_COMPLETE. ${nodes.length} NODES RECOVERED.`);
          }
        } catch (e) {
          addLog("SUPABASE: CONNECTION ERROR. LOCAL_CACHE ONLY.");
        }
        setIsSyncing(false);
      }
    };
    initEngine();
  }, []);

  useEffect(() => {
    if (terminalRef.current) terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
  }, [logs]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-30), `[${new Date().toLocaleTimeString().split(' ')[0]}] ${msg}`]);
  };

  const applyArchetype = (arch: Archetype) => {
    setGear(arch.gear);
    setJustInjected(true);
    setActiveTab('ARMORY');
    addLog(`ARCHETYPE_INJECTION: ${arch.name.toUpperCase()} (CATEGORY: ${arch.category})`);
    setTimeout(() => setJustInjected(false), 1500);
  };

  const startEvolution = async (isReforge = false) => {
    if (!evolution.originalImage) return;
    if (engineTier === 'PRO' && !hasUserKey) {
       // @ts-ignore
       await window.aistudio.openSelectKey();
       setHasUserKey(true);
       return;
    }
    if (!isReforge) {
      setActiveTab('TERMINAL');
      setEvolution(prev => ({ ...prev, status: 'processing' }));
      addLog(`FORGE: STARTING GEN_SHIFT | TIER: ${engineTier}`);
    }
    try {
      const result = await evolveSprite(evolution.originalImage, gear, rarity, variation, isReforge, engineTier === 'PRO');
      const score = await compareSilhouettes(evolution.originalImage, result);
      setDriftScore(score);
      if (score < 92 && !isReforge) {
        addLog(`DRIFT: ${score.toFixed(1)}%. AUTO_REFORGE TRIGGERED.`);
        return startEvolution(true);
      }
      setEvolution(prev => ({ ...prev, evolvedImage: result, status: 'completed' }));
      addLog("FORGE: PROCESS_STABLE. AWAITING COMMIT.");
      setSliderPos(50);
    } catch (err: any) {
      addLog("CRITICAL: FORGE OVERHEAT.");
      setEvolution(prev => ({ ...prev, status: 'error' }));
    }
  };

  const commitToTree = async () => {
    if (!evolution.evolvedImage) return;
    setIsSyncing(true);
    addLog("COMMIT: PERSISTING TO CLOUD...");
    
    try {
      const nodeId = 'node-' + Date.now();
      const imageUrl = await uploadSprite(nodeId, evolution.evolvedImage);
      
      const newNode: EvolutionNode = { 
        id: nodeId, 
        parentId: activeNodeId, 
        image: imageUrl, 
        description: `${rarity} ${variation}`, 
        timestamp: Date.now(),
        rarity, 
        variation 
      };

      await saveNode(newNode);
      setHistory(prev => [...prev, newNode]);
      setActiveNodeId(nodeId);
      setEvolution(prev => ({ ...prev, originalImage: imageUrl, evolvedImage: null, status: 'idle' }));
      setGear({ head: '', body: '', legs: '', weapon: '', back: '' });
      addLog("COMMIT: SYNCED SUCCESSFULLY.");
      setActiveTab('ARMORY');
    } catch (e) {
      addLog("COMMIT: SYNC_FAILED. SAVED LOCALLY.");
    }
    setIsSyncing(false);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const imageData = ev.target?.result as string;
        const rootId = 'root-' + Date.now();
        setIsSyncing(true);
        try {
          const imageUrl = await uploadSprite(rootId, imageData);
          const rootNode: EvolutionNode = { id: rootId, parentId: null, image: imageUrl, description: 'Base', timestamp: Date.now() };
          await saveNode(rootNode);
          setHistory([rootNode]);
          setActiveNodeId(rootId);
          setEvolution({ ...evolution, originalImage: imageUrl, evolvedImage: null, status: 'idle' });
          addLog("SYSTEM: NEW_ANCHOR_ESTABLISHED.");
        } catch (e) {
          addLog("ERROR: CLOUD_UPLOAD_FAILED.");
        }
        setIsSyncing(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const rootNode = history.find(n => n.parentId === null);

  return (
    <div className="flex flex-col gap-10">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-[#0f1115] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col min-h-[520px]">
            <div className="flex border-b border-slate-800 bg-black/40">
              {(['ARMORY', 'ARCHETYPES', 'FORGE_SPEC', 'TERMINAL'] as TabType[]).map((tab) => (
                <button key={tab} onClick={() => setActiveTab(tab)} className={`flex-1 py-3.5 text-[8px] font-bold tracking-[0.2em] transition-all relative ${activeTab === tab ? 'text-indigo-400 bg-indigo-500/5' : 'text-slate-600 hover:text-slate-400'}`}>
                  {tab.replace('_', ' ')}
                  {activeTab === tab && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-500 shadow-[0_0_8px_#6366f1]"></div>}
                </button>
              ))}
            </div>

            <div className="p-6 flex-grow">
              {activeTab === 'ARMORY' && (
                <div className="space-y-5 animate-in fade-in duration-300">
                   <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Slots de Equipo</span>
                    {isSyncing && <span className="text-[7px] text-indigo-400 animate-pulse font-bold uppercase">Syncing...</span>}
                  </div>
                  {Object.entries(gear).map(([slot, value]) => (
                    <div key={slot} className="space-y-1">
                      <label className="text-[8px] text-slate-700 font-mono uppercase">{slot}</label>
                      <input 
                        value={value} 
                        onChange={(e) => setGear(prev => ({ ...prev, [slot]: e.target.value }))} 
                        className={`w-full bg-black border p-2.5 text-[11px] font-mono text-slate-300 outline-none rounded-lg transition-all ${justInjected ? 'border-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.2)]' : 'border-slate-800 focus:border-indigo-500'}`}
                        placeholder={`Inyectar ${slot}...`} 
                      />
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'ARCHETYPES' && (
                <div className="space-y-4 animate-in fade-in h-[400px] flex flex-col">
                  <div className="flex gap-2 mb-4">
                    <button 
                      onClick={() => setSelectedCollection('STANDARD')}
                      className={`flex-1 py-1.5 text-[7px] font-bold rounded border transition-all ${selectedCollection === 'STANDARD' ? 'bg-slate-800 border-slate-600 text-slate-100' : 'bg-transparent border-slate-800 text-slate-600'}`}
                    >
                      STANDARD
                    </button>
                    <button 
                      onClick={() => setSelectedCollection('EXOTIC_STEEL')}
                      className={`flex-1 py-1.5 text-[7px] font-bold rounded border transition-all ${selectedCollection === 'EXOTIC_STEEL' ? 'bg-indigo-900 border-indigo-700 text-indigo-100 shadow-[0_0_10px_rgba(99,102,241,0.2)]' : 'bg-transparent border-slate-800 text-slate-600'}`}
                    >
                      EXOTIC STEEL
                    </button>
                  </div>

                  <div className="flex-grow overflow-y-auto scrollbar-hide pr-2 space-y-3">
                    {ARCHETYPE_LIBRARY.filter(a => a.category === selectedCollection).length > 0 ? (
                      ARCHETYPE_LIBRARY.filter(a => a.category === selectedCollection).map((arch) => (
                        <button 
                          key={arch.id} 
                          onClick={() => applyArchetype(arch)} 
                          className="w-full group flex flex-col p-4 bg-black/40 border border-slate-800 rounded-xl hover:border-indigo-500 transition-all text-left"
                        >
                          <div className="flex justify-between items-start mb-1">
                            <span className="text-[10px] font-bold text-slate-300">{arch.name}</span>
                            <span className={`text-[7px] px-1.5 rounded uppercase font-bold ${arch.category === 'EXOTIC_STEEL' ? 'text-rose-500 bg-rose-500/10' : 'text-indigo-500 bg-indigo-500/10'}`}>
                              {arch.race}
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <p className="text-[8px] text-slate-600 font-mono italic truncate max-w-[150px]">{arch.gear.weapon}</p>
                            <span className="text-[6px] text-slate-500 font-bold uppercase">{arch.vibe}</span>
                          </div>
                        </button>
                      ))
                    ) : (
                      <div className="h-full flex flex-col items-center justify-center opacity-20 py-10">
                        <span className="text-xl mb-2">🚫</span>
                        <p className="text-[8px] uppercase tracking-widest font-bold">No Data in Set</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'FORGE_SPEC' && (
                <div className="space-y-8 animate-in fade-in duration-300">
                  <div className="space-y-4">
                    <label className="text-[10px] text-slate-500 uppercase font-bold tracking-widest block">Engine Tier</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button onClick={() => setEngineTier('FLASH')} className={`py-3 rounded-xl border text-[9px] font-bold transition-all ${engineTier === 'FLASH' ? 'bg-indigo-600 border-indigo-400 text-white' : 'bg-black border-slate-800 text-slate-600'}`}>FLASH</button>
                      <button onClick={() => setEngineTier('PRO')} className={`py-3 rounded-xl border text-[9px] font-bold transition-all ${engineTier === 'PRO' ? 'bg-amber-600 border-amber-400 text-white' : 'bg-black border-slate-800 text-slate-600'}`}>PRO</button>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <label className="text-[10px] text-slate-500 uppercase font-bold tracking-widest block">Rarity Calibration</label>
                    <div className="grid grid-cols-2 gap-2">
                      {RARITIES.map(r => (
                        <button key={r} onClick={() => setRarity(r)} className={`py-2 px-2 rounded-lg border text-[8px] font-bold transition-all ${rarity === r ? 'bg-indigo-600 border-indigo-400 text-white' : 'bg-black border-slate-800 text-slate-600'}`}>{r.toUpperCase()}</button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'TERMINAL' && (
                <div ref={terminalRef} className="bg-black/80 border border-slate-800 rounded-xl p-4 font-mono text-[10px] h-[340px] overflow-y-auto space-y-1.5 text-slate-600 scroll-smooth">
                  {logs.map((log, i) => <div key={i} className="flex gap-2"><span className="opacity-30">[{i}]</span>{log}</div>)}
                </div>
              )}
            </div>

            <div className="p-6 border-t border-slate-800">
              <button 
                onClick={() => startEvolution()} 
                disabled={evolution.status === 'processing' || !evolution.originalImage} 
                className="w-full py-4 rounded-xl pixel-font text-[10px] uppercase bg-indigo-700 hover:bg-indigo-600 text-white border-b-4 border-indigo-950 active:translate-y-1 disabled:opacity-50 transition-all shadow-lg"
              >
                {evolution.status === 'processing' ? 'FORGING...' : 'ENGAGE FORGE'}
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="bg-[#0f1115] border border-slate-800 rounded-2xl p-8 min-h-[640px] flex flex-col relative shadow-2xl">
            <div className="flex justify-between items-end mb-8 relative z-10">
              <div>
                <span className="text-slate-600 text-[8px] uppercase tracking-[0.4em] mb-1 block">Visualizer</span>
                <h2 className="pixel-font text-[11px] text-indigo-500 uppercase">Evolution Chamber</h2>
              </div>
              <button onClick={() => fileInputRef.current?.click()} className="text-[9px] font-bold px-4 py-2 bg-slate-900 border border-slate-800 rounded hover:border-indigo-500/50 transition-all uppercase tracking-wider">LOAD ANCHOR</button>
              <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" />
            </div>

            <div className="flex-grow flex items-center justify-center relative z-10">
              {evolution.evolvedImage ? (
                <div className="relative w-[320px] h-[320px] bg-black/20 rounded-xl flex items-center justify-center overflow-hidden shadow-[0_0_50px_rgba(99,102,241,0.15)]">
                   <img crossOrigin="anonymous" src={evolution.originalImage} className="absolute inset-0 w-full h-full object-contain opacity-40 grayscale image-rendering-pixelated" style={{ imageRendering: 'pixelated' }} />
                   <div className="absolute inset-0 w-full h-full overflow-hidden" style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}>
                     <img crossOrigin="anonymous" src={evolution.evolvedImage} className="w-[320px] h-[320px] object-contain image-rendering-pixelated" style={{ imageRendering: 'pixelated' }} />
                   </div>
                   <div className="absolute top-0 bottom-0 w-0.5 bg-indigo-500 shadow-[0_0_10px_#6366f1]" style={{ left: `${sliderPos}%` }}></div>
                   <input type="range" min="0" max="100" value={sliderPos} onChange={(e) => setSliderPos(Number(e.target.value))} className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20" />
                </div>
              ) : evolution.originalImage ? (
                 <img crossOrigin="anonymous" src={evolution.originalImage} className="w-[320px] h-[320px] object-contain image-rendering-pixelated" style={{ imageRendering: 'pixelated' }} />
              ) : (
                <div className="text-center opacity-20 group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                  <div className="w-16 h-16 border-2 border-dashed border-slate-700 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:border-indigo-500 transition-colors">
                    <span className="text-xl">+</span>
                  </div>
                  <p className="pixel-font text-[8px] text-slate-800 uppercase tracking-widest group-hover:text-indigo-400 transition-colors">Awaiting Identity Block</p>
                </div>
              )}
            </div>

            {evolution.status === 'completed' && (
              <div className="mt-8 flex gap-4 relative z-10 animate-in slide-in-from-bottom-4 duration-300">
                <button onClick={commitToTree} disabled={isSyncing} className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-[10px] font-bold uppercase transition-all shadow-lg shadow-indigo-900/20 disabled:opacity-50">
                  {isSyncing ? 'SYNCING...' : 'Commit Evolution'}
                </button>
                <button onClick={() => setEvolution(prev => ({ ...prev, evolvedImage: null, status: 'idle' }))} className="px-6 py-3 border border-slate-800 text-slate-600 hover:text-slate-400 rounded-xl text-[10px] font-bold uppercase transition-all">
                  Discard
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <section className="bg-[#0f1115] border border-slate-800 rounded-3xl p-10 overflow-x-auto shadow-2xl">
        <div className="flex items-center justify-between mb-12">
          <h3 className="pixel-font text-[10px] text-slate-500 uppercase tracking-[0.2em]">Historical Lineage Tree</h3>
          <div className="h-0.5 flex-grow mx-8 bg-slate-900"></div>
          <span className="text-[8px] text-slate-700 font-bold uppercase tracking-widest">{history.length} NODES</span>
        </div>
        <div className="min-w-max p-4">
          {rootNode ? (
            <TreeBranch 
              node={rootNode} 
              allNodes={history} 
              onSelect={(n) => { 
                setActiveNodeId(n.id); 
                setEvolution({ ...evolution, originalImage: n.image, evolvedImage: null, status: 'idle' }); 
                addLog(`RESTORE_ANCHOR: GEN_${n.id.slice(-4).toUpperCase()}`);
              }} 
              activeId={activeNodeId} 
            />
          ) : (
            <div className="py-12 text-center text-slate-700 font-mono text-[10px] uppercase border-2 border-dashed border-slate-900 rounded-2xl">
              No branches detected in current lineage. Upload an anchor to begin.
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
