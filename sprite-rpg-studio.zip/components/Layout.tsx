
import React from 'react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-start p-4 md:p-8 bg-[#0a0a0c] text-slate-200">
      <header className="w-full max-w-6xl flex flex-col items-center mb-12">
        <h1 className="pixel-font text-2xl md:text-4xl text-indigo-500 mb-2 glow-text tracking-tighter text-center">
          SPRITEFORGE
        </h1>
        <p className="text-slate-500 font-medium tracking-widest uppercase text-xs md:text-sm">
          RPG Engine • Evolution Module v2.5
        </p>
      </header>
      <main className="w-full max-w-6xl">
        {children}
      </main>
      <footer className="mt-auto pt-12 pb-6 text-slate-600 text-xs tracking-widest uppercase flex gap-4">
        <span>© 2024 Pixel Labs</span>
        <span>•</span>
        <span>Powered by Gemini 2.5</span>
      </footer>
    </div>
  );
};
