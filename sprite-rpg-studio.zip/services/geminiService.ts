
import { GoogleGenAI } from "@google/genai";
import { GearSlots, RarityTier, OutfitVariation } from "../types";

export async function evolveSprite(
  base64Image: string,
  gear: GearSlots,
  rarity: RarityTier,
  variation: OutfitVariation,
  strictMode: boolean = false,
  useProModel: boolean = false
): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const modelName = useProModel ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
  
  const cleanedBase64 = base64Image.replace(/^data:image\/\w+;base64,/, '');

  const prompt = `
    [BLOCK 1: IDENTITY ANCHOR]
    ROLE: Industrial RPG Pixel Art Evolution Engine.
    INPUT: High-quality original character sprite.
    CONSTRAINT: You must preserve the EXACT body proportions, skin tone, hair color, and facial expression. 
    ${strictMode ? "STRICT_CONSISTENCY: DO NOT CHANGE A SINGLE PIXEL OF THE CHARACTER'S SILHOUETTE." : "MAINTAIN pose and character orientation perfectly."}

    [BLOCK 2: EQUIPMENT INJECTION]
    Apply a professional re-outfitting based on these gear slots:
    - HEAD: ${gear.head || 'Keep original'}
    - BODY: ${gear.body || 'Keep original'}
    - LEGS: ${gear.legs || 'Keep original'}
    - WEAPON: ${gear.weapon || 'Keep original'}
    - BACK: ${gear.back || 'Keep original'}

    [BLOCK 3: EVOLUTION PARAMETERS]
    - TIER: ${rarity.toUpperCase()}
    - STYLE: ${variation.toUpperCase()}
    - VIBE: High-fantasy battle gear, ornate metals, decorative fabrics. If bikini-armor or revealing parts are mentioned in the GEAR block, render them with high-fidelity metallic textures and dynamic cloth physics while maintaining character dignity.

    [BLOCK 4: RENDER PROTOCOL]
    - PIXEL-ART: 1:1 pixel mapping. No blurry edges. No gradients outside the color palette.
    - PALETTE: Use high-contrast ramps based on the original character's skin and primary colors.
    - BACKGROUND: Return character on absolute TRANSPARENT background.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          { inlineData: { data: cleanedBase64, mimeType: 'image/png' } },
          { text: prompt },
        ],
      },
      config: useProModel ? {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: "1K"
        }
      } : undefined
    });

    let generatedImageUrl = '';
    const candidate = response.candidates?.[0];
    if (candidate?.content?.parts) {
      for (const part of candidate.content.parts) {
        if (part.inlineData) {
          generatedImageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!generatedImageUrl) throw new Error("CRITICAL_FAILURE: Output stream empty.");
    return generatedImageUrl;
  } catch (error: any) {
    console.error("SpriteForge Engine Error:", error);
    if (error.message?.includes("Requested entity was not found")) {
       throw new Error("KEY_NOT_FOUND");
    }
    throw error;
  }
}
