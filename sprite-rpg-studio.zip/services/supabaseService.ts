
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { EvolutionNode } from '../types';

// Estas variables se configurarán en Vercel
const supabaseUrl = (window as any).process?.env?.SUPABASE_URL || '';
const supabaseAnonKey = (window as any).process?.env?.SUPABASE_ANON_KEY || '';

export const supabase = supabaseUrl ? createClient(supabaseUrl, supabaseAnonKey) : null;

export async function uploadSprite(id: string, base64: string): Promise<string> {
  if (!supabase) return base64;
  
  const byteCharacters = atob(base64.split(',')[1]);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  const blob = new Blob([byteArray], { type: 'image/png' });

  const { data, error } = await supabase.storage
    .from('sprites')
    .upload(`${id}.png`, blob, { upsert: true });

  if (error) throw error;
  
  const { data: publicUrl } = supabase.storage
    .from('sprites')
    .getPublicUrl(data.path);
    
  return publicUrl.publicUrl;
}

export async function saveNode(node: EvolutionNode) {
  if (!supabase) return;
  const { error } = await supabase
    .from('evolution_nodes')
    .insert([{
      id: node.id,
      parent_id: node.parentId,
      image_url: node.image,
      description: node.description,
      rarity: node.rarity,
      variation: node.variation
    }]);
  if (error) throw error;
}

export async function fetchAllNodes(): Promise<EvolutionNode[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from('evolution_nodes')
    .select('*')
    .order('created_at', { ascending: true });
    
  if (error) throw error;
  
  return data.map(d => ({
    id: d.id,
    parentId: d.parent_id,
    image: d.image_url,
    description: d.description,
    timestamp: new Date(d.created_at).getTime(),
    rarity: d.rarity,
    variation: d.variation
  }));
}
