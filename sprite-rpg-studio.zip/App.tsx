
import React from 'react';
import { Layout } from './components/Layout';
import { SpriteForge } from './components/SpriteForge';

const App: React.FC = () => {
  return (
    <Layout>
      <div className="mb-12 flex flex-col md:flex-row justify-between items-end gap-6">
        <div className="flex-1">
          <h2 className="text-xl md:text-2xl font-extrabold mb-4 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-indigo-600 shadow-[0_0_20px_-5px_rgba(79,70,229,1)] flex items-center justify-center text-lg">⚔️</span>
            Evolution Chamber
          </h2>
          <p className="text-slate-500 max-w-2xl text-xs md:text-sm leading-relaxed font-medium uppercase tracking-wider">
            Deploy industrial-grade pixel-art re-outfitting. SpriteForge uses the <span className="text-indigo-400 font-bold">4-Block Starter Protocol</span> to iterate character gear while preserving identity anchors.
          </p>
        </div>
        <div className="flex gap-4">
          <div className="px-4 py-2 border border-slate-800 rounded-lg bg-[#0f1115]">
            <span className="block text-[7px] text-slate-700 font-bold uppercase tracking-widest mb-1">Engine Status</span>
            <span className="block text-[9px] text-emerald-500 font-mono flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
              OPTIMAL
            </span>
          </div>
          <div className="px-4 py-2 border border-slate-800 rounded-lg bg-[#0f1115]">
            <span className="block text-[7px] text-slate-700 font-bold uppercase tracking-widest mb-1">Current Protocol</span>
            <span className="block text-[9px] text-indigo-400 font-mono">STARTER_KIT_V1</span>
          </div>
        </div>
      </div>

      <SpriteForge />

      <section className="mt-20 border-t border-slate-800 pt-16 grid grid-cols-1 md:grid-cols-3 gap-12">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 bg-indigo-500 rotate-45"></div>
            <h4 className="font-bold text-slate-200 text-xs uppercase tracking-widest">Engine Core</h4>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed font-medium">Maintains the primary identity anchor. Prohibits any changes to bone structure, facial features, or biological traits during gear shifts.</p>
        </div>
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 bg-cyan-500 rotate-45"></div>
            <h4 className="font-bold text-slate-200 text-xs uppercase tracking-widest">Silhouette Lock</h4>
            <span className="text-[8px] bg-cyan-500/10 text-cyan-500 px-1 rounded font-bold">ACTIVE</span>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed font-medium">Guarantees that the character's footprint remains constant. New equipment is wrapped around the body volume without distortion.</p>
        </div>
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 bg-rose-500 rotate-45"></div>
            <h4 className="font-bold text-slate-200 text-xs uppercase tracking-widest">Palette Binder</h4>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed font-medium">Extracts the original shading ramps and color DNA. All new gear tiers are automatically harmonized with the base palette logic.</p>
        </div>
      </section>
    </Layout>
  );
};

export default App;
