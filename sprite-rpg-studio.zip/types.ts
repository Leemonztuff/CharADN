
export type RarityTier = 'Common' | 'Rare' | 'Epic' | 'Legendary';
export type OutfitVariation = 'Standard' | 'Ornate' | 'Battle-worn' | 'Simple';

export interface GearSlots {
  head: string;
  body: string;
  legs: string;
  weapon: string;
  back: string;
}

export interface SpriteEvolution {
  id: string;
  originalImage: string;
  evolvedImage: string | null;
  outfitDescription: string;
  timestamp: number;
  status: 'idle' | 'processing' | 'completed' | 'error';
  pixelGuardStatus?: 'analyzing' | 'passed' | 'drifted' | 'reforging';
  rarity?: RarityTier;
  variation?: OutfitVariation;
}

export interface EvolutionNode {
  id: string;
  parentId: string | null;
  image: string;
  description: string;
  timestamp: number;
  rarity?: RarityTier;
  variation?: OutfitVariation;
}

export interface ForgeSettings {
  keepOriginalPose: boolean;
  pixelScale: number;
}
